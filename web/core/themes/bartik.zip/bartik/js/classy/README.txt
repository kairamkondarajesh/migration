WHAT IS THIS DIRECTORY FOR?
--------------------------------
This directory is for JS files previously inherited from the Classy theme.

WHY ARE CLASSY JS FILES BEING COPIED HERE?
-------------------------------------------
Classy will be deprecated during the Drupal 9 lifecycle. To prepare for Classy's
removal, JS files that would otherwise be inherited from Classy are copied
here.

JS files that differ from the Classy versions should not be placed in this
directory or any subdirectory.
